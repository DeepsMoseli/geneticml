import numpy as np
import pandas as pd
from sklearn import model_selection
from sklearn.metrics import accuracy_score, roc_auc_score, mean_squared_error

def Main():
    print("Welcome to geneticml!")

if __name__=="__main__":
    Main()
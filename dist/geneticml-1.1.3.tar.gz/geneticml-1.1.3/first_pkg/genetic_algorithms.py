#includes all implemented genetic algorithms
import numpy

class algorithms:
    def __init__(self):
        self.name = "Name"

    def hello(self):
        print("Hello from algorithms")


